{
    'name': 'Portal Existencias',
    'version': '1.0',
    'summary': 'Módulo para mostrar existencias a usuarios tipo portal',
    'sequence': 10,
    'author': 'CEITSA',
    'category': 'Website',
    'depends': ['website'],
    'data': [
        'views/portal_stock_template.xml'
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
